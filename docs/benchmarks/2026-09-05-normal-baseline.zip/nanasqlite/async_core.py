"""
NanaSQLite Async Wrapper: Non-blocking async interface for NanaSQLite.
(NanaSQLite 非同期ラッパー: NanaSQLiteのための非ブロッキング非同期インターフェース)

Provides async/await support for all NanaSQLite operations, preventing blocking
in async applications by running database operations in a thread pool.

データベース操作をスレッドプールで実行することにより、非同期アプリケーションでのブロッキングを防ぎ、
すべてのNanaSQLite操作に対してasync/awaitサポートを提供します。

Example:
    >>> import asyncio
    >>> from nanasqlite import AsyncNanaSQLite
    >>>
    >>> async def main():
    ...     async with AsyncNanaSQLite("mydata.db") as db:
    ...         await db.aset("user", {"name": "Nana", "age": 20})
    ...         user = await db.aget("user")
    ...         print(user)
    >>>
    >>> asyncio.run(main())
"""

from __future__ import annotations

import asyncio
import functools
import logging
import math
import queue
import weakref
from collections.abc import AsyncIterator
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from typing import Any

import apsw

from .cache import CacheType
from .compat import (
    HAS_ORJSON as HAS_ORJSON,  # noqa: F401
)
from .compat import (
    HAS_VALIDKIT as HAS_VALIDKIT,  # noqa: F401
)
from .compat import (
    EllipsisType as EllipsisType,  # noqa: F401
)
from .compat import (
    validkit_validate as validkit_validate,  # noqa: F401
)
from .core import (
    _UNSET,
    IDENTIFIER_PATTERN,
    NanaSQLite,
    V2Config,
)
from .exceptions import NanaSQLiteClosedError, NanaSQLiteDatabaseError
from .protocols import NanaHook


class _Admission:
    """Shared across wrappers using the same executor; event-loop owned."""

    def __init__(self, limit: int | None) -> None:
        self.semaphore = asyncio.Semaphore(limit) if limit is not None else None
        self.active: set[asyncio.Future] = set()
        self.closing = False

    def completed(self, future: asyncio.Future) -> None:
        self.active.discard(future)
        if self.semaphore is not None:
            self.semaphore.release()
        # A cancelled caller cannot observe the worker's eventual exception.
        if not future.cancelled():
            future.exception()


class AsyncNanaSQLite:
    """
    Async wrapper for NanaSQLite with optimized thread pool executor.
    (最適化されたスレッドプールを使用するNanaSQLiteの非同期ラッパー)

    All database operations are executed in a dedicated thread pool executor to prevent
    blocking the async event loop. This allows NanaSQLite to be used safely
    in async applications like FastAPI, aiohttp, etc.

    データベース操作はすべて専用のスレッドプール内で実行され、非同期イベントループのブロックを防ぎます。
    これにより、FastAPIやaiohttpなどの非同期アプリケーションで安全に使用できます。

    The implementation uses a configurable thread pool for optimal concurrency
    and performance in high-load scenarios.

    高負荷なシナリオにおいて最適な並行性とパフォーマンスを実現するため、
    カスタマイズ可能なスレッドプールを使用しています。

    Args:
        db_path: SQLiteデータベースファイルのパス
        table: 使用するテーブル名 (デフォルト: "data")
        bulk_load: Trueの場合、初期化時に全データをメモリに読み込む
        optimize: Trueの場合、WALモードなど高速化設定を適用
        cache_size_mb: SQLiteキャッシュサイズ（MB）、デフォルト64MB
        strict_sql_validation: Trueの場合、未許可の関数等を含むクエリを拒否 (v1.2.0)
        max_clause_length: SQL句の最大長（ReDoS対策、v1.2.0）
        max_workers: スレッドプール内の最大ワーカー数（デフォルト: 5）
        thread_name_prefix: スレッド名のプレフィックス（デフォルト: "AsyncNanaSQLite"）

    Example:
        >>> async with AsyncNanaSQLite("mydata.db") as db:
        ...     await db.aset("config", {"theme": "dark"})
        ...     config = await db.aget("config")
        ...     print(config)

        >>> # 高負荷環境向けの設定
        >>> async with AsyncNanaSQLite("mydata.db", max_workers=10) as db:
        ...     # 並行処理が多い場合に最適化
        ...     results = await asyncio.gather(*[db.aget(f"key_{i}") for i in range(100)])
    """

    def __init__(
        self,
        db_path: str,
        table: str = "data",
        bulk_load: bool = False,
        optimize: bool = True,
        cache_size_mb: int = 64,
        max_workers: int = 5,
        strict_sql_validation: bool = True,
        validator: Any | None = None,
        coerce: bool = False,
        v2_mode: bool = False,
        v2_config: V2Config | None = None,
        **kwargs: Any,
    ) -> None:
        """
        Args:
            db_path: SQLiteデータベースファイルのパス
            table: 使用するテーブル名 (デフォルト: "data")
            bulk_load: Trueの場合、初期化時に全データをメモリに読み込む
            optimize: Trueの場合、WALモードなど高速化設定を適用
            cache_size_mb: SQLiteキャッシュサイズ（MB）、デフォルト64MB
            max_workers: スレッドプール内の最大ワーカー数（デフォルト: 5）
            thread_name_prefix: スレッド名のプレフィックス（デフォルト: "AsyncNanaSQLite"）
            strict_sql_validation: Trueの場合、未許可の関数等を含むクエリを拒否 (v1.2.0)
            cache_strategy: キャッシュ戦略 (v1.1.0)
            encryption_key: 暗号化キー (v1.3.1)
            lock_timeout: ロック取得のタイムアウト秒数。Noneで無制限待機。
            max_pending_operations: Optional positive bound on submitted executor
                jobs (running plus queued), shared by table children.
            admission_timeout: Positive timeout in seconds for admission only;
                None waits indefinitely. Requires max_pending_operations.
            cache_consistency: "manual" (default) or "auto", inherited by children.
            validator: バリデーション用スキーマ
            v2_mode: Trueの場合、新しいV2エンジンの試験的機能を使用する
            v2_config: V2エンジンの構成オブジェクト
            **kwargs: その他の設定項目のための可変引数 (allowed_sql_functions, cache_ttl 等)
        """
        # Extract parameters from kwargs for backward compatibility and internal use
        thread_name_prefix = kwargs.get("thread_name_prefix", "AsyncNanaSQLite")
        cache_strategy = kwargs.get("cache_strategy", CacheType.UNBOUNDED)
        encryption_key = kwargs.get("encryption_key")
        allow_legacy_plaintext = bool(kwargs.get("allow_legacy_plaintext", False))
        allowed_sql_functions = kwargs.get("allowed_sql_functions")
        forbidden_sql_functions = kwargs.get("forbidden_sql_functions")
        max_clause_length = kwargs.get("max_clause_length", 1000)
        read_pool_size = kwargs.get("read_pool_size", 0)
        cache_size = kwargs.get("cache_size")
        cache_ttl = kwargs.get("cache_ttl")
        cache_persistence_ttl = kwargs.get("cache_persistence_ttl", False)
        encryption_mode = kwargs.get("encryption_mode", "aes-gcm")
        lock_timeout = kwargs.get("lock_timeout")
        # override coerce from kwargs if provided (v1 signature compatibility)
        coerce = kwargs.get("coerce", coerce)
        hooks = kwargs.get("hooks")
        memory_first = bool(kwargs.get("memory_first", False))
        flush_mode = kwargs.get("flush_mode", "time" if memory_first else "immediate")
        flush_interval = kwargs.get("flush_interval", kwargs.get("memory_flush_interval", 5.0) if memory_first else 3.0)
        flush_count = kwargs.get("flush_count", 100)
        v2_chunk_size = kwargs.get("v2_chunk_size", 1000)
        v2_max_dlq_size = kwargs.get("v2_max_dlq_size", 1000)
        v2_enable_metrics = kwargs.get("v2_enable_metrics", False)
        warn_duplicate_table_instance = kwargs.get("warn_duplicate_table_instance", True)
        self._cache_consistency = kwargs.get("cache_consistency", "manual")
        self._memory_first = bool(kwargs.get("memory_first", False))
        max_pending = kwargs.get("max_pending_operations")
        admission_timeout = kwargs.get("admission_timeout")
        if max_pending is not None and (
            isinstance(max_pending, bool) or not isinstance(max_pending, int) or max_pending <= 0
        ):
            raise ValueError("max_pending_operations must be a positive integer or None")
        if admission_timeout is not None and (
            isinstance(admission_timeout, bool)
            or not isinstance(admission_timeout, (int, float))
            or not math.isfinite(admission_timeout)
            or admission_timeout <= 0
        ):
            raise ValueError("admission_timeout must be a positive finite number or None")
        if admission_timeout is not None and max_pending is None:
            raise ValueError("admission_timeout requires max_pending_operations")
        # Unbounded jobs must be drained too, including cancelled callers.
        self._admission = _Admission(max_pending)
        self._admission_timeout = admission_timeout
        self._closing = False
        self._close_task: asyncio.Task | None = None
        self._initialization_task: asyncio.Task | None = None

        self._db_path = db_path
        self._table = table
        self._bulk_load = bulk_load
        self._optimize = optimize
        self._cache_size_mb = cache_size_mb
        self._max_workers = max_workers
        self._thread_name_prefix = thread_name_prefix
        self._read_pool_size = read_pool_size
        self._read_pool: queue.Queue | None = None
        self._strict_sql_validation = strict_sql_validation
        self._allowed_sql_functions = allowed_sql_functions
        self._forbidden_sql_functions = forbidden_sql_functions
        self._max_clause_length = max_clause_length
        self._cache_strategy = cache_strategy
        self._cache_size = cache_size
        self._cache_ttl = cache_ttl
        self._cache_persistence_ttl = cache_persistence_ttl
        self._encryption_key = encryption_key
        self._encryption_mode = encryption_mode
        self._allow_legacy_plaintext = allow_legacy_plaintext
        self._lock_timeout = lock_timeout
        self._warn_duplicate_table_instance = bool(warn_duplicate_table_instance)
        self._validator_raw = validator
        self._coerce_raw: bool = bool(coerce)
        self._hooks_raw: list[NanaHook] = hooks or []

        # v2 Architecture Setup
        # v2_config が渡された場合はその値を優先し、個別パラメータより上書きする（後方互換のため個別引数も維持）
        if v2_config is not None:
            flush_mode = v2_config.flush_mode
            flush_interval = v2_config.flush_interval
            flush_count = v2_config.flush_count
            v2_chunk_size = v2_config.chunk_size
            v2_max_dlq_size = v2_config.max_dlq_size
            v2_enable_metrics = v2_config.enable_metrics

        self._v2_mode = v2_mode
        self._flush_mode = flush_mode
        self._flush_interval = flush_interval
        self._flush_count = flush_count
        self._v2_chunk_size = v2_chunk_size
        self._v2_max_dlq_size = v2_max_dlq_size
        self._v2_enable_metrics = v2_enable_metrics

        self._closed = False
        self._child_instances = weakref.WeakSet()  # WeakSetによる弱参照追跡（死んだ参照は自動的にクリーンアップ）
        self._is_connection_owner = True

        # 専用スレッドプールエグゼキューターを作成
        self._executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix=thread_name_prefix)
        self._db: NanaSQLite | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._owns_executor = True  # このインスタンスがエグゼキューターを所有
        # _init_lock はイベントループ内で初めて使われる時に生成する（__init__はループ外から呼ばれる可能性があるため）
        self._init_lock: asyncio.Lock | None = None

    @property
    def _validator(self) -> Any:
        """後方互換性とテストのためのプロパティ"""
        if self._db is not None:
            return self._db._validator
        return getattr(self, "_validator_raw", None)

    @property
    def _coerce(self) -> bool:
        """後方互換性とテストのためのプロパティ"""
        if self._db is not None:
            return self._db._coerce
        return getattr(self, "_coerce_raw", False)

    @property
    def _hooks(self) -> list[NanaHook]:
        """設定されているフックのリストを返します。"""
        if self._db is not None:
            return self._db._hooks
        return getattr(self, "_hooks_raw", [])

    async def add_hook(self, hook: NanaHook) -> None:
        """
        [v1.5.0 Feature] Add a hook/constraint to intercept read, write, and delete operations.

        Args:
            hook: Any object implementing the NanaHook protocol.
        """
        if self._db is not None:
            await self._run_in_executor(self._db.add_hook, hook)
        else:
            if not hasattr(self, "_hooks_raw"):
                self._hooks_raw = []
            self._hooks_raw.append(hook)

    async def _ensure_initialized(self) -> None:
        """Shield lazy connection creation from cancellation of the first caller."""
        if self._closed or self._closing:
            if not getattr(self, "_is_connection_owner", True):
                raise NanaSQLiteClosedError(f"Parent database connection is closed (table: {self._table!r})")
            raise NanaSQLiteClosedError("Database connection is closing or closed")
        if self._admission is not None and self._admission.closing:
            raise NanaSQLiteClosedError("Parent database connection is closing or closed")
        task = self._initialization_task
        if task is not None and not task.done():
            await asyncio.shield(task)
            return
        if self._db is not None:
            return
        task = asyncio.create_task(self._initialize())
        self._initialization_task = task
        # Observe failure even if every waiting caller has been cancelled.
        task.add_done_callback(self._initialization_completed)
        await asyncio.shield(task)

    def _initialization_completed(self, task: asyncio.Task) -> None:
        if not task.cancelled():
            task.exception()
        if self._initialization_task is task:
            self._initialization_task = None

    async def _initialize(self) -> None:
        """Ensure the underlying sync database is initialized"""
        if self._closed or self._closing:
            if not getattr(self, "_is_connection_owner", True):
                raise NanaSQLiteClosedError(f"Parent database connection is closed (table: {self._table!r})")
            raise NanaSQLiteClosedError("Database connection is closed")

        if self._db is not None:
            return

        # _init_lock はイベントループ内で最初に呼ばれた時に生成する（イベントループ安全）
        if self._init_lock is None:
            self._init_lock = asyncio.Lock()

        async with self._init_lock:
            # Check again inside lock
            if self._closed or self._closing:
                raise NanaSQLiteClosedError("Database is closing or closed")
            if self._db is not None:
                return

            # Initialize in thread pool to avoid blocking
            loop = asyncio.get_running_loop()
            self._loop = loop
            self._db = await loop.run_in_executor(
                self._executor,
                lambda: NanaSQLite(
                    self._db_path,
                    table=self._table,
                    bulk_load=self._bulk_load,
                    optimize=self._optimize,
                    cache_size_mb=self._cache_size_mb,
                    strict_sql_validation=self._strict_sql_validation,
                    allowed_sql_functions=self._allowed_sql_functions,
                    forbidden_sql_functions=self._forbidden_sql_functions,
                    max_clause_length=self._max_clause_length,
                    cache_strategy=self._cache_strategy,
                    cache_size=self._cache_size,
                    cache_ttl=self._cache_ttl,
                    cache_persistence_ttl=self._cache_persistence_ttl,
                    encryption_key=self._encryption_key,
                    encryption_mode=self._encryption_mode,
                    allow_legacy_plaintext=self._allow_legacy_plaintext,
                    lock_timeout=self._lock_timeout,
                    validator=self._validator,
                    coerce=self._coerce,
                    hooks=self._hooks,
                    v2_mode=self._v2_mode,
                    flush_mode=self._flush_mode,
                    flush_interval=self._flush_interval,
                    flush_count=self._flush_count,
                    v2_chunk_size=self._v2_chunk_size,
                    v2_max_dlq_size=self._v2_max_dlq_size,
                    v2_enable_metrics=self._v2_enable_metrics,
                    warn_duplicate_table_instance=self._warn_duplicate_table_instance,
                    cache_consistency=self._cache_consistency,
                    memory_first=self._memory_first,
                ),
            )

            # Initialize Read-Only Pool if requested
            if self._read_pool_size > 0:
                self._read_pool = queue.Queue(maxsize=self._read_pool_size)

                def _init_pool_connection():
                    # mode=ro (Read-Only) is mandatory for safety
                    flags = apsw.SQLITE_OPEN_READONLY | apsw.SQLITE_OPEN_URI
                    uri_path = f"file:{self._db_path}?mode=ro"

                    for _ in range(self._read_pool_size):
                        conn = apsw.Connection(uri_path, flags=flags)
                        # Apply optimizations to pool connections too (WAL, mmap)
                        # We use a cursor to set PRAGMAs
                        c = conn.cursor()
                        c.execute("PRAGMA journal_mode = WAL")
                        c.execute("PRAGMA synchronous = NORMAL")
                        c.execute("PRAGMA mmap_size = 268435456")
                        # Smaller cache for pool connections (don't hog memory)
                        c.execute("PRAGMA cache_size = -2000")  # ~2MB
                        c.execute("PRAGMA temp_store = MEMORY")
                        self._read_pool.put(conn)

                await loop.run_in_executor(self._executor, _init_pool_connection)

    @contextmanager
    def _read_connection(self):
        """
        Context manager to yield a connection for read-only operations.
        Yields a pooled connection if available, otherwise yields the main DB connection.
        """
        if self._read_pool is None:
            with self._db._lock:
                yield self._db._connection
            return

        # Capture reference locally to ensure safety even if self._read_pool is set to None elsewhere
        pool = self._read_pool
        conn = pool.get()
        try:
            yield conn
        finally:
            pool.put(conn)

    async def _run_in_executor(self, func, *args):
        """Bound submitted work; cancellation never frees a running worker slot.

        Admission timeout means no work was submitted. After submission,
        cancellation does not undo a write: inspect its result before retrying.
        The bound covers executor jobs, not user-created waiting coroutines or
        the separate v2 write-back buffer.
        """
        # Public operations already initialize before resolving the bound DB
        # method. Avoid a second coroutine round-trip on every executor call.
        if self._db is None or self._initialization_task is not None:
            await self._ensure_initialized()
        loop = asyncio.get_running_loop()
        admission = self._admission
        semaphore = admission.semaphore
        if semaphore is not None:
            if self._admission_timeout is None:
                await semaphore.acquire()
            else:
                await asyncio.wait_for(semaphore.acquire(), self._admission_timeout)
        try:
            if self._closed or self._closing or admission.closing:
                raise NanaSQLiteClosedError("Database is closing or closed")
            future = loop.run_in_executor(self._executor, func, *args)
        except BaseException:
            if semaphore is not None:
                semaphore.release()
            raise
        admission.active.add(future)
        future.add_done_callback(admission.completed)
        return await asyncio.shield(future)

    async def aget_status(self) -> dict[str, Any]:
        """Return payload-free persistence diagnostics."""
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.get_status)

    async def aget_dlq_summary(self) -> list[dict[str, Any]]:
        """Return redacted failure codes and timestamps."""
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.get_dlq_summary)

    async def aiter_items(self, batch_size: int = 1000) -> AsyncIterator[tuple[str, Any]]:
        """Async keyset iteration; see NanaSQLite.iter_items for consistency rules."""
        if isinstance(batch_size, bool) or not isinstance(batch_size, int) or batch_size <= 0:
            raise ValueError("batch_size must be a positive integer")
        await self._ensure_initialized()
        await self._run_in_executor(self._db._prepare_iteration)
        after = None
        while True:
            page = await self._run_in_executor(self._db._iter_items_page, after, batch_size)
            if not page:
                return
            after = page[-1][0]
            for item in page:
                yield item
            if len(page) < batch_size:
                return

    def _try_get_unbounded_cache_hit(self, key: str, default: Any = None) -> tuple[bool, Any]:
        """Return a cached unbounded value without crossing the executor boundary."""
        db = self._db
        if db is None or db._cache_consistency == "auto" or db._lru_mode or db._has_hooks:
            return False, None
        try:
            return True, db._data[key]
        except KeyError:
            if key in db._absent_keys:
                return True, default
            return False, None

    def _try_contains_unbounded_cache_hit(self, key: str) -> tuple[bool, bool]:
        """Return cached unbounded containment knowledge when available."""
        db = self._db
        if db is None or db._cache_consistency == "auto" or db._lru_mode:
            return False, False
        try:
            _ = db._data[key]
            return True, True
        except KeyError:
            if key in db._absent_keys:
                return True, False
            return False, False

    def _try_batch_get_unbounded_cache_hit(self, keys: list[str]) -> tuple[bool, dict[str, Any]]:
        """Return batch_get results without executor when every key is cache-known."""
        db = self._db
        if db is None or db._cache_consistency == "auto" or db._lru_mode or db._has_hooks:
            return False, {}

        results = {}
        for key in keys:
            try:
                results[key] = db._data[key]
            except KeyError:
                if key not in db._absent_keys:
                    return False, {}
        return True, results

    # ==================== Async Dict-like Interface ====================

    async def aget(self, key: str, default: Any = None) -> Any:
        """
        非同期でキーの値を取得

        Args:
            key: 取得するキー
            default: キーが存在しない場合のデフォルト値

        Returns:
            キーの値（存在しない場合はdefault）

        Example:
            >>> user = await db.aget("user")
            >>> config = await db.aget("config", {})
        """
        await self._ensure_initialized()
        db = self._db
        if db._cache_consistency == "manual" and not db._lru_mode and not db._has_hooks:
            try:
                return db._data[key]
            except KeyError:
                if key in db._absent_keys:
                    return default
        return await self._run_in_executor(db.get, key, default)

    async def aset(self, key: str, value: Any) -> None:
        """
        非同期でキーに値を設定

        Args:
            key: 設定するキー
            value: 設定する値

        Example:
            >>> await db.aset("user", {"name": "Nana", "age": 20})
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.__setitem__, key, value)

    async def adelete(self, key: str) -> None:
        """
        非同期でキーを削除

        Args:
            key: 削除するキー

        Raises:
            KeyError: キーが存在しない場合

        Example:
            >>> await db.adelete("old_data")
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.__delitem__, key)

    async def acontains(self, key: str) -> bool:
        """
        非同期でキーの存在確認

        Args:
            key: 確認するキー

        Returns:
            キーが存在する場合True

        Example:
            >>> if await db.acontains("user"):
            ...     print("User exists")
        """
        await self._ensure_initialized()
        if self._db is None:
            raise RuntimeError("Database not initialized")
        cache_hit, exists = self._try_contains_unbounded_cache_hit(key)
        if cache_hit:
            return exists
        return await self._run_in_executor(self._db.__contains__, key)

    async def alen(self) -> int:
        """
        非同期でデータベースの件数を取得

        Returns:
            データベース内のキーの数

        Example:
            >>> count = await db.alen()
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.__len__)

    async def akeys(self) -> list[str]:
        """
        非同期で全キーを取得

        Returns:
            全キーのリスト

        Example:
            >>> keys = await db.akeys()
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.keys)

    async def avalues(self) -> list[Any]:
        """
        非同期で全値を取得

        Returns:
            全値のリスト

        Example:
            >>> values = await db.avalues()
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.values)

    async def aitems(self) -> list[tuple[str, Any]]:
        """
        非同期で全アイテムを取得

        Returns:
            全アイテムのリスト（キーと値のタプル）

        Example:
            >>> items = await db.aitems()
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.items)

    async def apop(self, key: str, *args) -> Any:
        """
        非同期でキーを削除して値を返す

        Args:
            key: 削除するキー
            *args: デフォルト値（オプション）

        Returns:
            削除されたキーの値

        Example:
            >>> value = await db.apop("temp_data")
            >>> value = await db.apop("maybe_missing", "default")
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.pop, key, *args)

    async def aupdate(self, mapping: dict | None = None, **kwargs) -> None:
        """
        非同期で複数のキーを更新

        Args:
            mapping: 更新するキーと値のdict
            **kwargs: キーワード引数として渡す更新

        Example:
            >>> await db.aupdate({"key1": "value1", "key2": "value2"})
            >>> await db.aupdate(key3="value3", key4="value4")
        """
        await self._ensure_initialized()

        # Create a wrapper function that captures kwargs
        def update_wrapper():
            self._db.update(mapping, **kwargs)

        await self._run_in_executor(update_wrapper)

    async def aflush(self, wait: bool = False) -> None:
        """
        [v2 Feature] 非同期でv2エンジンのバックグラウンドバッファとキューをSQLiteに明示的にフラッシュする。
        v2_modeがFalseの場合は何もしない。

        Example:
            >>> await db.aflush(wait=True)
        """
        await self._ensure_initialized()

        # Create a tiny closure to pass the keyword argument to flush
        def _flush_wrapper():
            self._db.flush(wait=wait)

        await self._run_in_executor(_flush_wrapper)

    async def aclear(self) -> None:
        """
        非同期で全データを削除

        Example:
            >>> await db.aclear()
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.clear)

    # ==================== v2 DLQ / Metrics API ====================

    async def aget_dlq(self) -> list[dict[str, Any]]:
        """
        [v2 Feature] 非同期でデッドレターキュー（DLQ）の内容を取得します。
        v2モードが無効な場合は空のリストを返します。

        Example:
            >>> failed = await db.aget_dlq()
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.get_dlq)

    async def aretry_dlq(self) -> None:
        """
        [v2 Feature] 非同期でDLQ内の全アイテムを再試行キューに戻します。
        v2モードが無効な場合は何もしません。

        Example:
            >>> await db.aretry_dlq()
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.retry_dlq)

    async def aclear_dlq(self) -> None:
        """
        [v2 Feature] 非同期でDLQの内容をクリアします。
        v2モードが無効な場合は何もしません。

        Example:
            >>> await db.aclear_dlq()
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.clear_dlq)

    async def aget_v2_metrics(self) -> dict[str, Any]:
        """
        [v2 Feature] 非同期でメトリクス情報を取得します( v2_enable_metrics=True 時のみ有効)。
        v2モード自体またはメトリクスが無効な場合は空の辞書を返します。

        Example:
            >>> metrics = await db.aget_v2_metrics()
            >>> print(metrics["flush_count"])
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.get_v2_metrics)

    async def asetdefault(self, key: str, default: Any = None) -> Any:
        """
        非同期でキーが存在しない場合のみ値を設定

        Args:
            key: キー
            default: デフォルト値

        Returns:
            キーの値（既存または新規設定した値）

        Example:
            >>> value = await db.asetdefault("config", {})
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.setdefault, key, default)

    async def aupsert(
        self,
        table_name: str | None = None,
        data: dict[str, Any] | Any | None = None,
        *,
        conflict_columns: list[str] | None = None,
    ) -> None:
        """
        非同期でUPSERT（存在すれば更新、なければ挿入）を実行します。

        Args:
            table_name: テーブル名（またはv2互換モード時のキー）
            data: 挿入・更新するデータ（またはv2互換モード時の値）
            conflict_columns: 重複判定に使用するカラム名のリスト

        Example:
            >>> await db.aupsert("users", {"id": 1, "name": "Alice"})
            >>> await db.aupsert("user:1", {"name": "Nana"})
        """
        await self._ensure_initialized()
        func = functools.partial(self._db.upsert, table_name, data, conflict_columns=conflict_columns)
        return await self._run_in_executor(func)

    # Alias for consistency
    upsert = aupsert

    # ==================== Async Special Methods ====================

    async def load_all(self) -> None:
        """
        非同期で全データを一括ロード

        Example:
            >>> await db.load_all()
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.load_all)

    async def refresh(self, key: str | None = None) -> None:
        """
        非同期でキャッシュを更新

        Args:
            key: 更新するキー（Noneの場合は全キャッシュ）

        Example:
            >>> await db.refresh("user")
            >>> await db.refresh()  # 全キャッシュ更新
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.refresh, key)

    async def is_cached(self, key: str) -> bool:
        """
        非同期でキーがキャッシュ済みか確認

        Args:
            key: 確認するキー

        Returns:
            キャッシュ済みの場合True

        Example:
            >>> cached = await db.is_cached("user")
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.is_cached, key)

    async def batch_update(self, mapping: dict[str, Any]) -> None:
        """
        非同期で一括書き込み（高速）

        Args:
            mapping: 書き込むキーと値のdict

        Example:
            >>> await db.batch_update({
            ...     "key1": "value1",
            ...     "key2": "value2",
            ...     "key3": {"nested": "data"}
            ... })
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.batch_update, mapping)

    async def batch_update_partial(self, mapping: dict[str, Any]) -> dict[str, str]:
        """
        非同期で一括書き込み（部分成功モード）

        バリデーションまたはシリアライズに失敗したキーだけを拒否し、
        正常なキーは一括で保存する。返り値は拒否されたキーと理由の辞書。

        Args:
            mapping: 書き込むキーと値のdict

        Returns:
            拒否されたキー -> エラーメッセージ のdict
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.batch_update_partial, mapping)

    async def aincrement(
        self,
        key: str,
        amount: int | float = 1,
        *,
        field: str | None = None,
        default: int | float | None = None,
    ) -> Any:
        """Atomically increment a numeric value or top-level numeric dict field."""
        await self._ensure_initialized()
        operation = functools.partial(
            self._db.increment,
            key,
            amount,
            field=field,
            default=default,
        )
        return await self._run_in_executor(operation)

    async def apatch(self, key: str, changes: dict[str, Any], *, create: bool = False) -> Any:
        """Atomically apply a shallow dictionary merge and return the stored value."""
        await self._ensure_initialized()
        operation = functools.partial(self._db.patch, key, changes, create=create)
        return await self._run_in_executor(operation)

    async def batch_delete(self, keys: list[str]) -> None:
        """
        非同期で一括削除（高速）

        Args:
            keys: 削除するキーのリスト

        Example:
            >>> await db.batch_delete(["key1", "key2", "key3"])
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.batch_delete, keys)

    async def to_dict(self) -> dict:
        """
        非同期で全データをPython dictとして取得

        Returns:
            全データを含むdict

        Example:
            >>> data = await db.to_dict()
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.to_dict)

    async def copy(self) -> dict:
        """
        非同期で浅いコピーを作成

        Returns:
            全データのコピー

        Example:
            >>> data_copy = await db.copy()
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.copy)

    async def get_fresh(self, key: str, default: Any = None) -> Any:
        """
        非同期でDBから直接読み込み、キャッシュを更新

        Args:
            key: 取得するキー
            default: キーが存在しない場合のデフォルト値

        Returns:
            DBから取得した最新の値

        Example:
            >>> value = await db.get_fresh("key")
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.get_fresh, key, default)

    async def abatch_get(self, keys: list[str]) -> dict[str, Any]:
        """
        非同期で複数のキーを一度に取得

        Args:
            keys: 取得するキーのリスト

        Returns:
            取得に成功したキーと値の dict

        Example:
            >>> results = await db.abatch_get(["key1", "key2"])
        """
        await self._ensure_initialized()
        cache_hit, results = self._try_batch_get_unbounded_cache_hit(keys)
        if cache_hit:
            return results
        return await self._run_in_executor(self._db.batch_get, keys)

    # ==================== Async Pydantic Support ====================

    async def set_model(self, key: str, model: Any) -> None:
        """
        非同期でPydanticモデルを保存

        Args:
            key: 保存するキー
            model: Pydanticモデルのインスタンス

        Example:
            >>> from pydantic import BaseModel
            >>> class User(BaseModel):
            ...     name: str
            ...     age: int
            >>> user = User(name="Nana", age=20)
            >>> await db.set_model("user", user)
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.set_model, key, model)

    async def get_model(self, key: str, model_class: type = None) -> Any:
        """
        非同期でPydanticモデルを取得

        Args:
            key: 取得するキー
            model_class: Pydanticモデルのクラス

        Returns:
            Pydanticモデルのインスタンス

        Example:
            >>> user = await db.get_model("user", User)
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.get_model, key, model_class)

    # ==================== Async SQL Execution ====================

    async def execute(self, sql: str, parameters: tuple | None = None) -> Any:
        """
        非同期でSQLを直接実行

        Args:
            sql: 実行するSQL文
            parameters: SQLのパラメータ

        Returns:
            APSWのCursorオブジェクト

        Example:
            >>> cursor = await db.execute("SELECT * FROM data WHERE key LIKE ?", ("user%",))
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.execute, sql, parameters)

    async def execute_many(self, sql: str, parameters_list: list[tuple]) -> None:
        """
        非同期でSQLを複数のパラメータで一括実行

        Args:
            sql: 実行するSQL文
            parameters_list: パラメータのリスト

        Example:
            >>> await db.execute_many(
            ...     "INSERT OR REPLACE INTO custom (id, name) VALUES (?, ?)",
            ...     [(1, "Alice"), (2, "Bob"), (3, "Charlie")]
            ... )
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.execute_many, sql, parameters_list)

    async def fetch_one(self, sql: str, parameters: tuple | None = None) -> tuple | None:
        """
        非同期でSQLを実行して1行取得

        Args:
            sql: 実行するSQL文
            parameters: SQLのパラメータ

        Returns:
            1行の結果（tuple）

        Example:
            >>> row = await db.fetch_one("SELECT value FROM data WHERE key = ?", ("user",))
        """
        await self._ensure_initialized()

        def _fetch_one_impl():
            with self._read_connection() as conn:
                cursor = conn.execute(sql, parameters)
                return cursor.fetchone()

        return await self._run_in_executor(_fetch_one_impl)

    async def fetch_all(self, sql: str, parameters: tuple | None = None) -> list[tuple]:
        """
        非同期でSQLを実行して全行取得

        Args:
            sql: 実行するSQL文
            parameters: SQLのパラメータ

        Returns:
            全行の結果（tupleのリスト）

        Example:
            >>> rows = await db.fetch_all("SELECT key, value FROM data WHERE key LIKE ?", ("user%",))
        """
        await self._ensure_initialized()

        def _fetch_all_impl():
            with self._read_connection() as conn:
                cursor = conn.execute(sql, parameters)
                return list(cursor)

        return await self._run_in_executor(_fetch_all_impl)

    # ==================== Async SQLite Wrapper Functions ====================

    async def create_table(
        self, table_name: str, columns: dict, if_not_exists: bool = True, primary_key: str | None = None
    ) -> None:
        """
        非同期でテーブルを作成

        Args:
            table_name: テーブル名
            columns: カラム定義のdict
            if_not_exists: Trueの場合、存在しない場合のみ作成
            primary_key: プライマリキーのカラム名

        Example:
            >>> await db.create_table("users", {
            ...     "id": "INTEGER PRIMARY KEY",
            ...     "name": "TEXT NOT NULL",
            ...     "email": "TEXT UNIQUE"
            ... })
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.create_table, table_name, columns, if_not_exists, primary_key)

    async def create_index(
        self, index_name: str, table_name: str, columns: list[str], unique: bool = False, if_not_exists: bool = True
    ) -> None:
        """
        非同期でインデックスを作成

        Args:
            index_name: インデックス名
            table_name: テーブル名
            columns: インデックスを作成するカラムのリスト
            unique: Trueの場合、ユニークインデックスを作成
            if_not_exists: Trueの場合、存在しない場合のみ作成

        Example:
            >>> await db.create_index("idx_users_email", "users", ["email"], unique=True)
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.create_index, index_name, table_name, columns, unique, if_not_exists)

    async def query(
        self,
        table_name: str | None = None,
        columns: list[str] | None = None,
        where: str | None = None,
        parameters: tuple | None = None,
        order_by: str | None = None,
        limit: int | None = None,
        strict_sql_validation: bool | None = None,
        allowed_sql_functions: list[str] | None = None,
        forbidden_sql_functions: list[str] | None = None,
        override_allowed: bool = False,
    ) -> list[dict]:
        """
        非同期でSELECTクエリを実行

        Args:
            table_name: テーブル名
            columns: 取得するカラムのリスト
            where: WHERE句の条件
            parameters: WHERE句のパラメータ
            order_by: ORDER BY句
            limit: LIMIT句
            strict_sql_validation: Trueの場合、未許可の関数等を含むクエリを拒否
            allowed_sql_functions: このクエリで一時的に許可するSQL関数のリスト
            forbidden_sql_functions: このクエリで一時的に禁止するSQL関数のリスト
            override_allowed: Trueの場合、インスタンス許可設定を無視

        Returns:
            結果のリスト（各行はdict）

        Example:
            >>> results = await db.query(
            ...     table_name="users",
            ...     columns=["id", "name", "email"],
            ...     where="age > ?",
            ...     parameters=(20,),
            ...     order_by="name ASC",
            ...     limit=10
            ... )
        """
        await self._ensure_initialized()

        return await self._run_in_executor(
            self._shared_query_impl,
            table_name,
            columns,
            where,
            parameters,
            order_by,
            limit,
            None,  # offset
            None,  # group_by
            strict_sql_validation,
            allowed_sql_functions,
            forbidden_sql_functions,
            override_allowed,
        )

    async def query_with_pagination(
        self,
        table_name: str | None = None,
        columns: list[str] | None = None,
        where: str | None = None,
        parameters: tuple | None = None,
        order_by: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
        group_by: str | None = None,
        strict_sql_validation: bool | None = None,
        allowed_sql_functions: list[str] | None = None,
        forbidden_sql_functions: list[str] | None = None,
        override_allowed: bool = False,
    ) -> list[dict]:
        """
        非同期で拡張されたクエリを実行

        Args:
            table_name: テーブル名
            columns: 取得するカラム
            where: WHERE句
            parameters: パラメータ
            order_by: ORDER BY句
            limit: LIMIT句
            offset: OFFSET句
            group_by: GROUP BY句
            strict_sql_validation: Trueの場合、未許可の関数等を含むクエリを拒否
            allowed_sql_functions: このクエリで一時的に許可するSQL関数のリスト
            forbidden_sql_functions: このクエリで一時的に禁止するSQL関数のリスト
            override_allowed: Trueの場合、インスタンス許可設定を無視

        Returns:
            結果のリスト（各行はdict）

        Example:
            >>> results = await db.query_with_pagination(
            ...     table_name="users",
            ...     columns=["id", "name", "email"],
            ...     where="age > ?",
            ...     parameters=(20,),
            ...     order_by="name ASC",
            ...     limit=10,
            ...     offset=0
            ... )
        """
        await self._ensure_initialized()

        return await self._run_in_executor(
            self._shared_query_impl,
            table_name,
            columns,
            where,
            parameters,
            order_by,
            limit,
            offset,
            group_by,
            strict_sql_validation,
            allowed_sql_functions,
            forbidden_sql_functions,
            override_allowed,
        )

    async def table_exists(self, table_name: str) -> bool:
        """
        非同期でテーブルの存在確認

        Args:
            table_name: テーブル名

        Returns:
            存在する場合True

        Example:
            >>> exists = await db.table_exists("users")
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.table_exists, table_name)

    async def list_tables(self) -> list[str]:
        """
        非同期でデータベース内の全テーブル一覧を取得

        Returns:
            テーブル名のリスト

        Example:
            >>> tables = await db.list_tables()
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.list_tables)

    async def drop_table(self, table_name: str, if_exists: bool = True) -> None:
        """
        非同期でテーブルを削除

        Args:
            table_name: テーブル名
            if_exists: Trueの場合、存在する場合のみ削除

        Example:
            >>> await db.drop_table("old_table")
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.drop_table, table_name, if_exists)

    async def drop_index(self, index_name: str, if_exists: bool = True) -> None:
        """
        非同期でインデックスを削除

        Args:
            index_name: インデックス名
            if_exists: Trueの場合、存在する場合のみ削除

        Example:
            >>> await db.drop_index("idx_users_email")
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.drop_index, index_name, if_exists)

    async def sql_insert(self, table_name: str, data: dict) -> int:
        """
        非同期でdictから直接INSERT

        Args:
            table_name: テーブル名
            data: カラム名と値のdict

        Returns:
            挿入されたROWID

        Example:
            >>> rowid = await db.sql_insert("users", {
            ...     "name": "Alice",
            ...     "email": "alice@example.com",
            ...     "age": 25
            ... })
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.sql_insert, table_name, data)

    async def sql_update(self, table_name: str, data: dict, where: str, parameters: tuple | None = None) -> int:
        """
        非同期でdictとwhere条件でUPDATE

        Args:
            table_name: テーブル名
            data: 更新するカラム名と値のdict
            where: WHERE句の条件
            parameters: WHERE句のパラメータ

        Returns:
            更新された行数

        Example:
            >>> count = await db.sql_update("users",
            ...     {"age": 26, "status": "active"},
            ...     "name = ?",
            ...     ("Alice",)
            ... )
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.sql_update, table_name, data, where, parameters)

    async def sql_delete(self, table_name: str, where: str, parameters: tuple | None = None) -> int:
        """
        非同期でwhere条件でDELETE

        Args:
            table_name: テーブル名
            where: WHERE句の条件
            parameters: WHERE句のパラメータ

        Returns:
            削除された行数

        Example:
            >>> count = await db.sql_delete("users", "age < ?", (18,))
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.sql_delete, table_name, where, parameters)

    async def count(
        self,
        table_name: str | None = None,
        where: str | None = None,
        parameters: tuple | None = None,
        strict_sql_validation: bool | None = None,
        allowed_sql_functions: list[str] | None = None,
        forbidden_sql_functions: list[str] | None = None,
        override_allowed: bool = False,
    ) -> int:
        """
        非同期でレコード数を取得

        Args:
            table_name: テーブル名
            where: WHERE句の条件
            parameters: WHERE句のパラメータ
            strict_sql_validation: Trueの場合、未許可の関数等を含むクエリを拒否
            allowed_sql_functions: このクエリで一時的に許可するSQL関数のリスト
            forbidden_sql_functions: このクエリで一時的に禁止するSQL関数のリスト
            override_allowed: Trueの場合、インスタンス許可設定を無視

        Returns:
            レコード数

        Example:
            >>> count = await db.count("users", "age < ?", (18,))
        """
        await self._ensure_initialized()
        return await self._run_in_executor(
            self._db.count,
            table_name,
            where,
            parameters,
            strict_sql_validation,
            allowed_sql_functions,
            forbidden_sql_functions,
            override_allowed,
        )

    async def vacuum(self) -> None:
        """
        非同期でデータベースを最適化（VACUUM実行）

        Example:
            >>> await db.vacuum()
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.vacuum)

    # ==================== Transaction Control ====================

    async def begin_transaction(self) -> None:
        """
        非同期でトランザクションを開始

        Example:
            >>> await db.begin_transaction()
            >>> try:
            ...     await db.sql_insert("users", {"name": "Alice"})
            ...     await db.sql_insert("users", {"name": "Bob"})
            ...     await db.commit()
            ... except:
            ...     await db.rollback()
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.begin_transaction)

    async def commit(self) -> None:
        """
        非同期でトランザクションをコミット

        Example:
            >>> await db.commit()
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.commit)

    async def rollback(self) -> None:
        """
        非同期でトランザクションをロールバック

        Example:
            >>> await db.rollback()
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.rollback)

    async def in_transaction(self) -> bool:
        """
        非同期でトランザクション状態を確認

        Returns:
            bool: トランザクション中の場合True

        Example:
            >>> status = await db.in_transaction()
            >>> print(f"In transaction: {status}")
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.in_transaction)

    def transaction(self):
        """
        非同期トランザクションのコンテキストマネージャ

        Example:
            >>> async with db.transaction():
            ...     await db.sql_insert("users", {"name": "Alice"})
            ...     await db.sql_insert("users", {"name": "Bob"})
            ...     # 自動的にコミット、例外時はロールバック
        """
        return _AsyncTransactionContext(self)

    # ==================== Context Manager Support ====================

    async def __aenter__(self):
        """Async context manager entry"""
        await self._ensure_initialized()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()
        return False

    async def aclear_cache(self) -> None:
        """
        メモリキャッシュをクリア (非同期)

        DBのデータは削除せず、メモリ上のキャッシュのみ破棄します。
        """
        if self._db is None:
            return
        await self._run_in_executor(self._db.clear_cache)

    async def clear_cache(self) -> None:
        """aclear_cache のエイリアス"""
        await self.aclear_cache()

    async def close(self) -> None:
        """Drain accepted work and close; caller cancellation is shielded."""
        if self._close_task is None:
            self._closing = True
            if self._owns_executor and self._admission is not None:
                self._admission.closing = True
            self._close_task = asyncio.create_task(self._close_recoverable())
        await asyncio.shield(self._close_task)

    async def _close_recoverable(self) -> None:
        try:
            await self._close_impl()
        except BaseException:
            if not self._closed:
                self._closing = False
                if self._owns_executor:
                    self._admission.closing = False
                self._close_task = None
            raise

    async def _close_impl(self) -> None:
        """
        非同期でデータベース接続を閉じる

        スレッドプールエグゼキューターもシャットダウンします。

        Example:
            >>> await db.close()
        """
        if self._closed:
            return

        if self._initialization_task is not None:
            await asyncio.gather(asyncio.shield(self._initialization_task), return_exceptions=True)
        if self._init_lock is not None:
            async with self._init_lock:
                pass
        if self._admission is not None:
            active = tuple(self._admission.active)
            if active:
                await asyncio.gather(*(asyncio.shield(f) for f in active), return_exceptions=True)

        if self._db is not None:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(self._executor, self._db.close)
            self._db = None

        self._closed = True

        # 子インスタンスに通知
        for child in self._child_instances:
            child._mark_parent_closed()
        self._child_instances.clear()

        # Close Read-Only Pool
        if self._read_pool:
            while True:
                conn = None
                try:
                    conn = self._read_pool.get_nowait()
                    conn.close()
                except queue.Empty:
                    # Queue is empty; safe to stop draining
                    break
                except AttributeError as e:
                    # Unexpected AttributeError - log and continue cleanup for resilience
                    logging.getLogger(__name__).warning(
                        "Unexpected AttributeError during pool cleanup: %s (conn=%r)",
                        e,
                        conn,
                    )
                except apsw.Error as e:
                    # Ignore close errors during best-effort cleanup but log at warning level
                    logging.getLogger(__name__).warning(
                        "Error while closing read-only NanaSQLite connection %r: %s",
                        conn,
                        e,
                    )
            self._read_pool = None

        # 所有しているエグゼキューターをシャットダウン（ノンブロッキング）
        if self._owns_executor and self._executor is not None:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._executor.shutdown, True)
            self._executor = None

    def _mark_parent_closed(self) -> None:
        """親インスタンスが閉じられた際に呼ばれる"""
        self._closed = True
        self._db = None
        # 子がさらに子を持っている場合も再帰的に閉じる
        for child in self._child_instances:
            child._mark_parent_closed()
        self._child_instances.clear()

    def __repr__(self) -> str:
        status = "initialized=True" if self._db is not None else "initialized=False"
        return f"AsyncNanaSQLite({self._db_path!r}, table={self._table!r}, max_workers={self._max_workers}, {status})"

    # ==================== Sync DB Access (for advanced use) ====================

    @property
    def sync_db(self) -> NanaSQLite | None:
        """
        同期DBインスタンスへのアクセス（上級者向け）

        Warning:
            このプロパティは上級者向けです。
            非同期コンテキストで同期操作を行うとイベントループがブロックされる可能性があります。
            通常は非同期メソッドを使用してください。

        Returns:
            内部のNanaSQLiteインスタンス
        """
        return self._db

    async def table(
        self,
        table_name: str,
        validator: Any | None | EllipsisType = _UNSET,
        coerce: bool | EllipsisType = _UNSET,
        hooks: list[NanaHook] | None | EllipsisType = _UNSET,
        warn_duplicate_table_instance: bool | EllipsisType = _UNSET,
    ) -> AsyncNanaSQLite:
        """
        非同期でサブテーブルのAsyncNanaSQLiteインスタンスを取得

        既に初期化済みの親インスタンスから呼ばれることを想定しています。
        接続とエグゼキューターは親インスタンスと共有されます。

        ⚠️ 重要な注意事項:
        - 同じテーブルに対して複数のインスタンスを作成しないでください
          各インスタンスは独立したキャッシュを持つため、キャッシュ不整合が発生します
        - 推奨: テーブルインスタンスを変数に保存して再利用してください

        非推奨:
            sub1 = await db.table("users")
            sub2 = await db.table("users")  # キャッシュ不整合の原因

        推奨:
            users_db = await db.table("users")
            # users_dbを使い回す

        Args:
            table_name: 取得するサブテーブル名
            validator: このテーブル用の validkit-py スキーマ。
                       指定しない場合は親インスタンスのスキーマを引き継ぐ。
                       ``None`` を明示的に渡すとバリデーションなしで使用できる。
            coerce: ``True`` の場合、validkit-py の自動変換機能を有効にする。
                    指定しない場合は親インスタンスの設定を引き継ぐ。
            hooks: このテーブル用のフックのリスト。
                   指定しない場合は親インスタンスのフックを引き継ぐ。
                   ``None`` を明示的に渡すとフックなしで使用できる。
            warn_duplicate_table_instance: 同じDB・同じテーブルの既存 table() インスタンスがある場合に警告する。
                                           指定しない場合は親インスタンスの設定を引き継ぐ。

        Returns:
            AsyncNanaSQLite: 指定したテーブルを操作するAsyncNanaSQLiteインスタンス

        Example:
            >>> async with AsyncNanaSQLite("mydata.db", table="main") as db:
            ...     users_db = await db.table("users")
            ...     products_db = await db.table("products")
            ...     await users_db.aset("user1", {"name": "Alice"})
            ...     await products_db.aset("prod1", {"name": "Laptop"})
        """
        # 親インスタンスが初期化済みであることを確認
        await self._ensure_initialized()

        loop = asyncio.get_running_loop()
        sub_db = await self._run_in_executor(
            lambda: self._db.table(
                table_name,
                validator=validator,
                coerce=coerce,
                hooks=hooks,
                warn_duplicate_table_instance=warn_duplicate_table_instance,
            ),
        )

        # 新しいAsyncNanaSQLiteラッパーを作成（__init__をバイパス）
        async_sub_db: AsyncNanaSQLite = object.__new__(AsyncNanaSQLite)
        async_sub_db._db_path = self._db_path
        async_sub_db._table = table_name
        async_sub_db._bulk_load = self._bulk_load
        async_sub_db._optimize = self._optimize
        async_sub_db._cache_size_mb = self._cache_size_mb
        async_sub_db._max_workers = self._max_workers
        async_sub_db._thread_name_prefix = self._thread_name_prefix + f"_{table_name}"
        async_sub_db._db = sub_db  # 接続を共有した同期版DBを設定
        async_sub_db._closed = False  # クローズ状態を初期化
        async_sub_db._closing = False
        async_sub_db._close_task = None
        async_sub_db._initialization_task = None
        async_sub_db._admission = self._admission
        async_sub_db._admission_timeout = self._admission_timeout
        async_sub_db._cache_consistency = self._cache_consistency
        async_sub_db._memory_first = sub_db._memory_first
        async_sub_db._init_lock = None
        async_sub_db._loop = loop  # イベントループを共有
        async_sub_db._executor = self._executor  # 同じエグゼキューターを共有
        async_sub_db._owns_executor = False  # エグゼキューターは所有しない
        async_sub_db._is_connection_owner = False  # 接続の所有権はない
        # セキュリティ関連の設定も親インスタンスから継承する
        async_sub_db._strict_sql_validation = self._strict_sql_validation
        async_sub_db._allowed_sql_functions = self._allowed_sql_functions
        async_sub_db._forbidden_sql_functions = self._forbidden_sql_functions
        async_sub_db._max_clause_length = self._max_clause_length
        # バリデーションスキーマを引き継ぐ
        async_sub_db._validator_raw = self._validator if validator is _UNSET else validator
        # coerce 設定を引き継ぐ
        async_sub_db._coerce_raw = self._coerce if coerce is _UNSET else bool(coerce)
        async_sub_db._hooks_raw = self._hooks if hooks is _UNSET else hooks
        # キャッシュ関連の設定を親インスタンスから継承する
        async_sub_db._cache_strategy = self._cache_strategy
        async_sub_db._cache_size = self._cache_size
        async_sub_db._cache_ttl = self._cache_ttl
        async_sub_db._cache_persistence_ttl = self._cache_persistence_ttl
        # 暗号化関連の設定を親インスタンスから継承する
        async_sub_db._encryption_key = self._encryption_key
        async_sub_db._encryption_mode = self._encryption_mode
        async_sub_db._allow_legacy_plaintext = self._allow_legacy_plaintext
        async_sub_db._lock_timeout = self._lock_timeout
        async_sub_db._warn_duplicate_table_instance = (
            self._warn_duplicate_table_instance
            if warn_duplicate_table_instance is _UNSET
            else bool(warn_duplicate_table_instance)
        )
        # v2アーキテクチャ関連の設定を親インスタンスから継承する
        async_sub_db._v2_mode = getattr(self, "_v2_mode", False)
        async_sub_db._flush_mode = getattr(self, "_flush_mode", "immediate")
        async_sub_db._flush_interval = getattr(self, "_flush_interval", 3.0)
        async_sub_db._flush_count = getattr(self, "_flush_count", 100)
        async_sub_db._v2_chunk_size = getattr(self, "_v2_chunk_size", 1000)
        async_sub_db._v2_max_dlq_size = getattr(self, "_v2_max_dlq_size", 1000)
        async_sub_db._v2_enable_metrics = getattr(self, "_v2_enable_metrics", False)
        # 子インスタンス管理
        async_sub_db._child_instances = weakref.WeakSet()
        self._child_instances.add(async_sub_db)

        # Read-Only Pool は sub-instance では使用しない (シンプルさと後方互換性のため)
        async_sub_db._read_pool_size = 0
        async_sub_db._read_pool = None
        return async_sub_db

    # ==================== Async Method Aliases (Consistency & Stability) ====================
    # For a fully 'a'-prefixed API and compatibility with all tests/benchmarks

    aload_all = load_all
    arefresh = refresh
    ais_cached = is_cached
    abatch_update = batch_update
    abatch_update_partial = batch_update_partial
    abatch_delete = batch_delete
    ato_dict = to_dict
    acopy = copy
    aget_fresh = get_fresh
    aset_model = set_model
    aget_model = get_model
    aexecute = execute
    aexecute_many = execute_many
    afetch_one = fetch_one
    afetch_all = fetch_all

    async def abackup(
        self,
        target_path: str,
        *,
        verify: bool = True,
        flush: bool = True,
        allow_incomplete: bool = False,
    ) -> None:
        """
        非同期でデータベースを指定のパスにバックアップします。

        Args:
            target_path: バックアップ先のファイルパス
            verify: バックアップ作成後に整合性を検証する
            flush: v2/memory_first の保留書き込みを先に同期フラッシュする
            allow_incomplete: DLQ が残る状態でのバックアップを許可する
        """
        await self._ensure_initialized()
        operation = functools.partial(
            self._db.backup,
            target_path,
            verify=verify,
            flush=flush,
            allow_incomplete=allow_incomplete,
        )
        await self._run_in_executor(operation)

    async def arestore(self, source_path: str) -> None:
        """
        非同期で指定のパスからデータベースをリストアします。

        Args:
            source_path: リストア元のファイルパス
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.restore, source_path)

    async def apragma(self, pragma_name: str, value: Any = None) -> Any:
        """
        非同期で PRAGMA を実行します。

        Args:
            pragma_name: PRAGMA名
            value: 設定する値（Noneの場合は取得）

        Returns:
            PRAGMAの結果
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.pragma, pragma_name, value)

    async def aget_table_schema(self, table_name: str | None = None) -> list[dict]:
        """
        非同期でテーブルのスキーマ情報を取得します。

        Args:
            table_name: 対象のテーブル名（Noneの場合は自身のテーブル）

        Returns:
            スキーマ情報のリスト
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.get_table_schema, table_name)

    async def alist_indexes(self, table_name: str | None = None) -> list[str]:
        """
        非同期でテーブルのインデックス一覧を取得します。

        Args:
            table_name: 対象のテーブル名（Noneの場合は自身のテーブル）

        Returns:
            インデックス名のリスト
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.list_indexes, table_name)

    async def aalter_table_add_column(self, table_name: str, column_name: str, column_type: str) -> None:
        """
        非同期でテーブルにカラムを追加します。

        Args:
            table_name: テーブル名
            column_name: カラム名
            column_type: カラムの型定義
        """
        await self._ensure_initialized()
        await self._run_in_executor(self._db.alter_table_add_column, table_name, column_name, column_type)

    async def aupsert(
        self, table_name: str | Any = None, data: Any = None, conflict_columns: list[str] | None = None
    ) -> int | None:
        """
        非同期で UPSERT 操作を実行します。

        Args:
            table_name: テーブル名、または第2引数がNoneの場合はキー名
            data: カラム名と値のdict、または第1引数がキー名の場合は値
            conflict_columns: 競合判定に使用するカラム（Noneの場合はINSERT OR REPLACE）

        Returns:
            挿入/更新されたROWID。キー/値ペア指定時はNone。
        """
        await self._ensure_initialized()
        return await self._run_in_executor(self._db.upsert, table_name, data, conflict_columns)

    acreate_table = create_table
    acreate_index = create_index
    aquery = query
    aquery_with_pagination = query_with_pagination
    atable = table
    atable_exists = table_exists
    alist_tables = list_tables
    adrop_table = drop_table
    asql_insert = sql_insert
    asql_update = sql_update
    asql_delete = sql_delete
    acount = count
    avacuum = vacuum

    def _shared_query_impl(
        self,
        table_name: str,
        columns: list[str],
        where: str,
        parameters: tuple | None,
        order_by: str,
        limit: int,
        offset: int | None = None,
        group_by: str | None = None,
        strict_sql_validation: bool | None = None,
        allowed_sql_functions: list[str] | None = None,
        forbidden_sql_functions: list[str] | None = None,
        override_allowed: bool = False,
    ) -> list[dict]:
        """Internal shared implementation for query execution"""
        target_table = self._db._safe_table if table_name is None else self._db._sanitize_identifier(table_name)

        # Validation (Delegated to Main Instance logic)
        v_args = {
            "strict": strict_sql_validation,
            "allowed": allowed_sql_functions,
            "forbidden": forbidden_sql_functions,
            "override_allowed": override_allowed,
        }

        # table_name is already validated via _sanitize_identifier above
        self._db._validate_expression(where, **v_args, context="where")
        self._db._validate_expression(order_by, **v_args, context="order_by")
        self._db._validate_expression(group_by, **v_args, context="group_by")
        if columns:
            for col in columns:
                self._db._validate_expression(col, **v_args, context="column")

        # Column handling
        if columns is None:
            columns_sql = "*"
        else:
            safe_cols = []
            for col in columns:
                if IDENTIFIER_PATTERN.match(col):
                    safe_cols.append(self._db._sanitize_identifier(col))
                else:
                    safe_cols.append(col)
            columns_sql = ", ".join(safe_cols)

        # Validate limit
        if limit is not None:
            if not isinstance(limit, int):
                raise ValueError(f"limit must be an integer, got {type(limit).__name__}")
            if limit < 0:
                raise ValueError("limit must be non-negative")

        if offset is not None:
            if not isinstance(offset, int):
                raise ValueError(f"offset must be an integer, got {type(offset).__name__}")
            if offset < 0:
                raise ValueError("offset must be non-negative")

        # SQL Construction
        sql = f"SELECT {columns_sql} FROM {target_table}"  # nosec
        if where:
            sql += f" WHERE {where}"
        if group_by:
            sql += f" GROUP BY {group_by}"
        if order_by:
            sql += f" ORDER BY {order_by}"
        if limit is not None:
            sql += f" LIMIT {limit}"
        if offset is not None:
            sql += f" OFFSET {offset}"

        # Execute on pool
        try:
            with self._read_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql, parameters)

                # Column name extraction using cursor metadata (robust against AS alias parsing issues)
                try:
                    description = cursor.getdescription()
                    col_names = [col_info[0] for col_info in description]
                except apsw.ExecutionCompleteError:
                    # Fallback for zero-row results (e.g., limit=0)
                    if columns is None:
                        # Get column names from table metadata
                        p_cursor = conn.cursor()
                        p_cursor.execute(f"PRAGMA table_info({target_table})")
                        col_names = [row[1] for row in p_cursor]
                    else:
                        # Extract aliases from provided columns list
                        col_names = NanaSQLite._extract_column_aliases(columns)

                # Convert to dict list
                return [dict(zip(col_names, row)) for row in cursor]
        except apsw.Error as e:
            raise NanaSQLiteDatabaseError(f"Failed to execute query: {e}", original_error=e) from e

    get = aget
    contains = acontains
    keys = akeys
    values = avalues
    items = aitems
    flush = aflush
    increment = aincrement
    patch = apatch
    get_dlq = aget_dlq
    retry_dlq = aretry_dlq
    clear_dlq = aclear_dlq
    get_v2_metrics = aget_v2_metrics


class _AsyncTransactionContext:
    """非同期トランザクションのコンテキストマネージャ"""

    def __init__(self, db: AsyncNanaSQLite):
        self.db = db

    async def __aenter__(self):
        await self.db.begin_transaction()
        return self.db

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            await self.db.commit()
        else:
            await self.db.rollback()
        return False
